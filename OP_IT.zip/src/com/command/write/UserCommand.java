package com.command.write;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.DAO;
import dto.UserDTO;

public class UserCommand implements Command{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {

	}
	
}
